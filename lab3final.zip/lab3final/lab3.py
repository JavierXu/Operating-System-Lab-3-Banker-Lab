import argparse
import math
import copy

#parse the argument: file name
parser = argparse.ArgumentParser(description="Banker's Algorithm")
parser.add_argument('input', type = str)
args = parser.parse_args()

#read the file
inputfile = open(args.input,"r")
banker_input = []
for val in inputfile.read().split():
    banker_input.append(val)
inputfile.close()

#store the value of number of tasks / number of resource types / number of resources
num_tasks = int(banker_input[0])
fifo_num_tasks = int(banker_input[0])
banker_num_tasks = int(banker_input[0])
num_resource_type = int(banker_input[1])

#available resources
num_resource = dict()

#put different activities in different tasks according to their task number
all_tasks = []
for i in range(num_tasks):
    all_tasks.append([])
for i in range(num_resource_type):
    num_resource[i] = int(banker_input[i+2])
starting_pos = 2+num_resource_type
task_order = 0
i = 0
while starting_pos+3 < len(banker_input):
    task_order = int(banker_input[starting_pos+1])-1
    all_tasks[task_order].append([banker_input[starting_pos]])
    r = len(all_tasks[task_order])-1
    all_tasks[task_order][r].append(int(banker_input[starting_pos+1]))
    all_tasks[task_order][r].append(int(banker_input[starting_pos+2]))
    all_tasks[task_order][r].append(int(banker_input[starting_pos+3]))
    starting_pos += 4
    
#rounding function
def normal_round(n):
    if n - math.floor(n) < 0.5:
        return math.floor(n)
    return math.ceil(n)

#Task class
class the_Task:
    def __init__(self, res_type):
        self.claim = [0]*res_type # claim of the task
        self.res = [0]*res_type # resources owned by the task
        self.activity = 0 # the activity being carried out by the task
        self.cycle = 0 # cycle of the task
        self.wait = 0 # waiting time of the task
        self.status = 0 #-1 for aborted, 0 for active, 1 for terminated
        self.outstanding_request = 0 # signal if the task is blocked
        self.task_num = math.inf
        self.compute_cycle = 0 # cycle of the task in computing

#setter and getter functions
    def set_task_num(self, num):
        self.task_num = num
    
    def get_task_num(self):
        return self.task_num

    def increase_res(self, res_type, num):
        self.res[res_type-1] += num

    def release_res(self, res_type,num):
        self.res[res_type-1] -= num

    def set_claim(self, res_type, clm):
        self.claim[res_type-1] = clm

    def increase_activity(self):
        self.activity += 1

    def decrease_activity(self):
        self.activity -= 1

    def get_activity(self):
        return self.activity

    def get_claim(self):
        return self.claim

    def get_resource(self):
        return self.res

    def increase_cycle(self):
        self.cycle += 1

    def set_cycle(self, num):
        self.cycle = num

    def get_cycle(self):
        return self.cycle

    def increase_wait(self):
        self.wait += 1

    def get_wait(self):
        return self.wait

    def set_wait(self, wait):
        self.wait = wait

    def terminated_status(self):
        self.status = 1

    def aborted_status(self): #task aborted, release all holding resources
        self.status = -1
        for i in range(len(self.res)):
            num_resource[i] += self.res[i]
            self.release_res(i+1,self.res[i])

    def get_status(self):
        return self.status

    def outstanding_request_detected(self):
        self.outstanding_request = 1

    def outstanding_request_eliminated(self):
        self.outstanding_request = 0

    def get_outstanding_request(self):
        return self.outstanding_request

    def set_compute(self, comp):
        self.compute_cycle = comp

    def decrease_compute(self):
        self.compute_cycle -= 1

    def get_compute(self):
        return self.compute_cycle

task_in_fifo = []
for i in range(fifo_num_tasks):
    task_in_fifo.append(the_Task(num_resource_type))

task_in_fifo_ori = []

task_in_banker = []
for i in range(banker_num_tasks):
    task_in_banker.append(the_Task(num_resource_type))


def FIFO():

    global fifo_num_tasks
    finished = 0
    blocked = []
    releas = [0]* num_resource_type
    computing = []

    while finished != num_tasks:

        #check blocked task, see if the request can be granted
        for t in blocked:
            ind = task_in_fifo.index(t)
            acti = t.get_activity()
            if t.get_status() != -1: # increase waiting time and cycle of the task
                t.increase_wait() 
                t.increase_cycle()
                
            if all_tasks[ind][acti][0] == "request" and t.get_status() == 0:
                
                if all_tasks[ind][acti][3] <= num_resource[all_tasks[ind][acti][2]-1]: # if ok for granting, then grant
                    t.increase_res(all_tasks[ind][acti][2],all_tasks[ind][acti][3])
                    num_resource[all_tasks[ind][acti][2]-1] -= all_tasks[ind][acti][3]
                    t.increase_activity() 
                    t.outstanding_request_eliminated()
                    
        for task in task_in_fifo:
                                 
            # check task activities
            index = task_in_fifo.index(task)
            act = task.get_activity()

            if all_tasks[index][act][0] == "initiate" and task not in computing:

                task.set_claim(all_tasks[index][act][2],all_tasks[index][act][3])
                task.increase_activity()
                task.increase_cycle()
                
            if all_tasks[index][act][0] == "request" and task not in blocked and task.get_status() == 0 and task not in computing:

                if all_tasks[index][act][3] <= num_resource[all_tasks[index][act][2]-1]: 
                    #if there is enough requested resource, grant it
                    task.increase_res(all_tasks[index][act][2],all_tasks[index][act][3])
                    num_resource[all_tasks[index][act][2]-1] -= all_tasks[index][act][3]
                    task.increase_activity()
                    
                else:
                    #otherwise, block it
                    task.outstanding_request_detected()
                    blocked.append(task)
                 
                task.increase_cycle()
                
            if all_tasks[index][act][0] == "release" and task not in blocked and task not in computing:
                
                task.release_res(all_tasks[index][act][2],all_tasks[index][act][3])
                #a placeholder that holds the release resource and adds them to available resources after all tasks have been through this cycle
                releas[all_tasks[index][act][2]-1] += all_tasks[index][act][3]
                task.increase_activity()
                task.increase_cycle()
                    
            
            if all_tasks[index][act][0] == "compute" and task not in computing:

                #mark task as being computed
                task.set_compute(all_tasks[index][act][2])
                computing.append(task)
                task.increase_activity()
            
            if all_tasks[index][act][0] == "terminate" and task.get_status() == 0 and task not in computing:
                
                task.terminated_status()
                finished += 1

        #add released resources back to available resources        
        for i in range(len(releas)):
            num_resource[i] += releas[i] 
            releas[i] = 0

        #if task is no longer blocked, remove it from block list
        for t in blocked:
            if t.get_outstanding_request() == 0:  
                blocked.pop(blocked.index(t))

       

        if len(blocked) != 0 and len(blocked) == (num_tasks-finished):
            for task in task_in_fifo: 
                #if the number of blocked tasks is equal to the number of active tasks, abort the lowest numbered tasks
                if task in blocked and task.get_status != -1 and all_tasks[task_in_fifo.index(task)][task.get_activity()][3] > num_resource[all_tasks[task_in_fifo.index(task)][task.get_activity()][2]-1] and all_tasks[task_in_fifo.index(task)][task.get_activity()][0] == "request":
                    task.aborted_status()   
                    fifo_num_tasks -= 1
                    task.set_cycle(0)
                    task.set_wait(0)                        
                    finished += 1
                    blocked.pop(blocked.index(task))

        #task in computing decrease compute cycles
        n=0
        while n < len(computing):
            computing[n].decrease_compute()
            computing[n].increase_cycle()
            if computing[n].get_compute() == 0:
                computing.pop(n)
                n -= 1
            n += 1


def Banker():
    global banker_num_tasks
    finished = 0
    blocked = []
    releas = [0]* num_resource_type
    computing = []
    potential_claim = []#used for test safe state

    for i in range(num_resource_type): #based first on the number of resource types
        potential_claim.append([])

    for i in range(len(potential_claim)): #then based on the number of tasks
        for no in range(num_tasks):
            potential_claim[i].append(0)

    while finished < num_tasks:
        for t in blocked:
            ind = task_in_banker.index(t)
            acti = t.get_activity()
            if t.get_status() != -1:
                t.increase_wait() 
                t.increase_cycle()
            if all_tasks[ind][acti][0] == "request" and t.get_status() == 0:
                
                #check if it is still safe after granting the resource: if after granting the resource, 
                #the available resources can satisfy any potential claims of any active task, then still safe, 
                #other wise not safe
                safe = 0
                potential_available = copy.deepcopy(num_resource)
                potential_available[all_tasks[ind][acti][2]-1] -= all_tasks[ind][acti][3]
                next_claim = copy.deepcopy(potential_claim)
                next_claim[all_tasks[ind][acti][2]-1][ind] -= all_tasks[ind][acti][3]
                for i in range(num_tasks):
                    safe_state = 0
                    for n in range(num_resource_type):
                        if next_claim[n][i] <= potential_available[n]:
                            safe_state += 1
                            if safe_state == num_resource_type:
                                safe = 1
                                break
                if safe == 1:
                    t.increase_res(all_tasks[ind][acti][2],all_tasks[ind][acti][3])
                    num_resource[all_tasks[ind][acti][2]-1] -= all_tasks[ind][acti][3]
                    t.increase_activity()
                    t.outstanding_request_eliminated()
                    potential_claim[all_tasks[ind][acti][2]-1][ind] = t.get_claim()[all_tasks[ind][acti][2]-1] - t.get_resource()[all_tasks[ind][acti][2]-1]
 

        for task in task_in_banker:
                                 
            index = task_in_banker.index(task)
            act = task.get_activity()

            if all_tasks[index][act][0] == "initiate" and task not in computing and task.get_status() == 0:
  
                #if claim is greater than available resources, then abort the task
                if all_tasks[index][act][3] > num_resource[all_tasks[index][act][2]-1]:
                    print("Banker aborts task " + str(all_tasks[index][act][1]) + " before run begins: ")
                    print("claim for resource " + str(all_tasks[index][act][2]) + " ("+ str(all_tasks[index][act][3]) + ") " + "exceeds number of units present " + "(" +str(num_resource[all_tasks[index][act][2]-1]) + ")")
                    potential_claim[all_tasks[index][act][2]-1][index] = math.inf
                    task.aborted_status()
                    task.set_cycle(0)
                    task.set_wait(0)                        
                    finished += 1

                #else set the claim
                else:
                    task.set_claim(all_tasks[index][act][2],all_tasks[index][act][3])
                    task.increase_activity()
                    task.increase_cycle()


            if all_tasks[index][act][0] == "request" and task not in blocked and task.get_status() == 0 and task not in computing:

                # if the task requested number of resources, together with the number of resources it already holds, 
                # exceeds the number of resources present, then abort the task
                if task.get_resource()[all_tasks[index][act][2]-1] + all_tasks[index][act][3] > task.get_claim()[all_tasks[index][act][2]-1]:
                    print("During cycle " + str(task.get_cycle()) + "-" + str(task.get_cycle()+1)+ " of Banker's algorithms")
                    print("Task " + str(all_tasks[index][act][1]) + "'s request exceeds its claim; aborted;", end = " ")
                    release_res = [0]*num_resource_type
                    for i in range(len(task.get_resource())):
                        release_res[i] += task.get_resource()[i]
                    for i in range(len(release_res)):
                        print(str(release_res[i])+" units of type "+ str(i+1) + " resources available next cycle")
                    potential_claim[all_tasks[index][act][2]-1][index] = math.inf
                    task.aborted_status()
                    task.set_cycle(0)
                    task.set_wait(0)                        
                    finished += 1

                else:
                    #check safe state
                    safe = 0
                    potential_available = copy.deepcopy(num_resource)
                    potential_available[all_tasks[index][act][2]-1] -= all_tasks[index][act][3]
                    next_claim = copy.deepcopy(potential_claim)
                    next_claim[all_tasks[index][act][2]-1][index] -= all_tasks[index][act][3]
                    for i in range(num_tasks):
                        safe_state = 0
                        for n in range(num_resource_type):
                            if next_claim[n][i] <= potential_available[n]:
                                safe_state += 1
                                if safe_state == num_resource_type:
                                    safe = 1
                                    break

                    if safe == 1:

                        task.increase_res(all_tasks[index][act][2],all_tasks[index][act][3])
                        num_resource[all_tasks[index][act][2]-1] -= all_tasks[index][act][3]
                        task.increase_activity()

                    else:

                        task.outstanding_request_detected()
                        blocked.append(task)

                    task.increase_cycle()
                    potential_claim[all_tasks[index][act][2]-1][index] = task.get_claim()[all_tasks[index][act][2]-1] - task.get_resource()[all_tasks[index][act][2]-1]

            if all_tasks[index][act][0] == "release" and task not in blocked and task not in computing:

                task.release_res(all_tasks[index][act][2],all_tasks[index][act][3])
                releas[all_tasks[index][act][2]-1] += all_tasks[index][act][3]
                task.increase_activity()
                task.increase_cycle()

            if all_tasks[index][act][0] == "compute" and task not in computing:
 
                task.set_compute(all_tasks[index][act][2])
                computing.append(task)
                task.increase_activity()
            
            if all_tasks[index][act][0] == "terminate" and task.get_status() == 0 and task not in computing:

                task.terminated_status()
                finished += 1
 

        for i in range(len(releas)):
            num_resource[i] += releas[i] 
            releas[i] = 0

        for t in blocked:
            if t.get_outstanding_request() == 0:
                blocked.pop(blocked.index(t))

        n=0
        while n < len(computing):
            computing[n].decrease_compute()
            computing[n].increase_cycle()
            
            if computing[n].get_compute() == 0:
                computing.pop(n)
                n -= 1
            n += 1

        #calculate the potential claim of each tasks
        for task in task_in_banker:
            index = task_in_banker.index(task)
            if task.get_status() == 0:
                for i in range(num_resource_type):
                    potential_claim[i][index] = (task.get_claim()[i] - task.get_resource()[i])



FIFO()

total_cycle = 0
total_wait = 0

for t in task_in_fifo:
    total_cycle += t.get_cycle()
    total_wait += t.get_wait()

print("FIFO")
for t in task_in_fifo:
    index = task_in_fifo.index(t)
    if t.get_status() != -1:
        print("Task " + str(index+1), end =" ")
        print(t.get_cycle(), end = " ")
        print(t.get_wait(), end = " ")
        print(str(normal_round((100 * t.get_wait()/t.get_cycle()))) + "%")
    elif t.get_status() == -1:
        print("Task " + str(index+1)+ " aborted")
print("total  "+str(total_cycle), end =" ")
print(total_wait, end =" ")
print(str(normal_round((100 * total_wait/total_cycle))) + "%")
print("\n")


Banker()

banker_total_cycle = 0
banker_total_wait = 0

for t in task_in_banker:
    banker_total_cycle += t.get_cycle()
    banker_total_wait += t.get_wait()

print("BANKER'S")
for t in task_in_banker:
    index = task_in_banker.index(t)
    if t.get_status() != -1:
        print("Task " + str(index+1), end =" ")
        print(t.get_cycle(), end = " ")
        print(t.get_wait(), end = " ")
        print(str(normal_round((100 * t.get_wait()/t.get_cycle()))) + "%")
    elif t.get_status() == -1:
        print("Task " + str(index+1)+ " aborted")
print("total  "+str(banker_total_cycle), end =" ")
print(banker_total_wait, end =" ")
print(str(normal_round((100 * banker_total_wait/banker_total_cycle))) + "%")